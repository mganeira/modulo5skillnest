insert into clientes (id, nombre, direccion, telefono) VALUES 
(10, 'Maria', 'Av Brasil', '942342333'),
(11, 'Paulo', 'Calle Larga', '93278763'),
(12, 'Luli', 'Calle Los Libertadores', '9348356484'),
(13, 'Pepe', 'Calle Libertad', '9832823233'),
(14, 'Milo', 'Ramon Freire', '973293239'),
(15, 'Maira', 'Ohhigins', '93827322');