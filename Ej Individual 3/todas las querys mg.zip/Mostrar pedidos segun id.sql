-- Proyectar pedidos de un cliente específico (ID = 2)
SELECT * FROM pedidos WHERE cliente_id = 2;