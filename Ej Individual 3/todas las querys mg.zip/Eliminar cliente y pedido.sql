DELETE FROM pedidos
WHERE cliente_id = 2;
DELETE FROM clientes WHERE id = 2;